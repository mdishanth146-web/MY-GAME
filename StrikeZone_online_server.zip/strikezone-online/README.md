# Strike Zone Online

One small Node server that does two jobs: it serves the game page and it runs the public match room.
No packages to install.

## Run on your own computer (to try it)
    node server.js
Open http://localhost:3000 in two browser tabs, press ONLINE BATTLE in both, JOIN MATCH, wait ~15 s.

## Put it on the internet (free options)
Players need nothing but the link. The host must support Node and WebSockets and give you https.

### Render.com (easiest)
1. Put this folder in a GitHub repository.
2. Render > New > Web Service > pick the repo.
3. Runtime: Node. Build command: (leave empty). Start command: `node server.js`. Plan: Free.
4. Open the URL Render gives you (https://yourname.onrender.com) and share it.
   (The free plan sleeps after ~15 min idle; the first visit takes ~30 s to wake it up.)

### Railway / Fly.io / any VPS
`node server.js` (or use the included Dockerfile). The server reads the `PORT` environment variable.
Put it behind https (Railway/Fly do this automatically; on a VPS use Caddy or nginx).

## How a match works
- Press ONLINE BATTLE, enter a name, JOIN MATCH.
- With 2+ players waiting a 15 s countdown starts; up to 20 players per match.
- Late joiners can still jump in during the first 12 s (the plane flight).
- Everyone gets the same map, loot and vending machines. Last player alive wins.
- Online matches are real players only (no bots). Rocket weapons are turned off online.

## Settings (environment variables / top of server.js)
PORT (default 3000) - COUNTDOWN seconds (15) - MAX_PLAYERS 20 - MIN_PLAYERS 2

## Status check
GET /health  ->  {"ok":true,"online":3,"phase":"playing","inMatch":3}

## Good to know
- Hits are decided by the shooter's device (normal for a small hobby game), so a modified client could cheat.
- One room only. For several rooms you would run several copies or extend `room` in server.js.
- Coins, rank and owned guns are saved in each player's own browser.
