// Strike Zone online server: serves the game files AND runs the public match room.
// No dependencies. Run:  node server.js     (needs Node 16+; listens on $PORT or 3000)
'use strict';
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');

const PORT = +process.env.PORT || 3000;
const ROOT = path.join(__dirname, 'public');
const MAX_PLAYERS = 20;      // per match
const MIN_PLAYERS = 2;       // needed to start a match
const COUNTDOWN = +process.env.COUNTDOWN || 15;        // seconds between "enough players" and match start
const JOIN_WINDOW = 12;      // seconds after start during which newcomers can still jump in
const SNAP_MS = 66;          // ~15 position updates per second
const MAX_CLIENTS = 200;

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css',
  '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.txt': 'text/plain; charset=utf-8',
};

// ------------------------------------------------------------------ static files
const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/health' || url.pathname === '/api/status') {
    res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    return res.end(JSON.stringify({ ok: true, online: clients.size, phase: room.phase, inMatch: participants().length }));
  }
  let rel = decodeURIComponent(url.pathname);
  if (rel.endsWith('/')) rel += 'index.html';
  const file = path.normalize(path.join(ROOT, rel));
  if (!file.startsWith(ROOT + path.sep) && file !== ROOT) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': path.basename(file) === 'index.html' ? 'no-cache' : 'public, max-age=3600',
    });
    res.end(data);
  });
});

// ------------------------------------------------------------------ minimal WebSocket (RFC 6455)
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
function wsSend(sock, str) {
  if (sock.destroyed || !sock.writable) return;
  const payload = Buffer.from(str);
  let head;
  if (payload.length < 126) head = Buffer.from([0x81, payload.length]);
  else if (payload.length < 65536) { head = Buffer.alloc(4); head[0] = 0x81; head[1] = 126; head.writeUInt16BE(payload.length, 2); }
  else { head = Buffer.alloc(10); head[0] = 0x81; head[1] = 127; head.writeBigUInt64BE(BigInt(payload.length), 2); }
  sock.write(Buffer.concat([head, payload]));
}
function wsControl(sock, opcode, payload) {
  if (sock.destroyed || !sock.writable) return;
  payload = payload || Buffer.alloc(0);
  sock.write(Buffer.concat([Buffer.from([0x80 | opcode, payload.length]), payload]));
}

server.on('upgrade', (req, sock) => {
  const url = new URL(req.url, 'http://x');
  const key = req.headers['sec-websocket-key'];
  if (url.pathname !== '/ws' || !key || (req.headers.upgrade || '').toLowerCase() !== 'websocket' || clients.size >= MAX_CLIENTS) {
    sock.end('HTTP/1.1 400 Bad Request\r\n\r\n'); return;
  }
  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  sock.setNoDelay(true);
  const c = newClient(sock);
  let buf = Buffer.alloc(0), frag = null;
  sock.on('data', chunk => {
    c.live = true;
    buf = Buffer.concat([buf, chunk]);
    if (buf.length > 1 << 20) return sock.destroy();
    for (;;) {
      if (buf.length < 2) return;
      const fin = !!(buf[0] & 0x80), op = buf[0] & 0x0f, masked = !!(buf[1] & 0x80);
      let len = buf[1] & 0x7f, off = 2;
      if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); off = 10; }
      if (len > 1 << 16) return sock.destroy();
      if (!masked) return sock.destroy();                // clients must mask
      if (buf.length < off + 4 + len) return;
      const mask = buf.subarray(off, off + 4);
      const data = Buffer.from(buf.subarray(off + 4, off + 4 + len));
      for (let i = 0; i < data.length; i++) data[i] ^= mask[i & 3];
      buf = buf.subarray(off + 4 + len);
      if (op === 8) { wsControl(sock, 8); sock.end(); return; }
      if (op === 9) { wsControl(sock, 10, data); continue; }
      if (op === 10) continue;
      if (op === 1 || op === 0) {
        frag = frag ? Buffer.concat([frag, data]) : data;
        if (fin) { const text = frag.toString('utf8'); frag = null; onMessage(c, text); }
      }
    }
  });
  const gone = () => dropClient(c);
  sock.on('close', gone); sock.on('error', gone); sock.on('end', () => sock.end());
});

// ------------------------------------------------------------------ room state
const clients = new Set();
const room = { phase: 'lobby', seed: 0, t0: 0, taken: new Set(), drops: new Map(), cd: null, cdTimer: null, endTimer: null, nStart: 0 };
let nextId = 1;

function newClient(sock) {
  const c = { id: 'p' + (nextId++), sock, name: '', joined: false, inMatch: false, alive: false, live: true,
    x: 0, y: 0, z: 0, yaw: 0, pitch: 0, wp: 'pistol', hp: 100, air: 1, spd: 0, dirty: false, msgs: 0, mt: Date.now() };
  clients.add(c); return c;
}
const send = (c, obj) => wsSend(c.sock, JSON.stringify(obj));
const participants = () => [...clients].filter(c => c.inMatch);
const aliveP = () => participants().filter(c => c.alive);
const waiting = () => [...clients].filter(c => c.joined && !c.inMatch);
function bcast(obj, except, onlyMatch) {
  const s = JSON.stringify(obj);
  for (const c of clients) { if (c === except || !c.joined) continue; if (onlyMatch && !c.inMatch) continue; wsSend(c.sock, s); }
}
const cleanName = n => (String(n || '').replace(/[^A-Za-z0-9 _.\-]/g, '').trim().slice(0, 12)) || 'Player';

function lobbyInfo() {
  return { t: 'lobby', n: waiting().length, cd: room.cd, phase: room.phase, inMatch: participants().length, need: MIN_PLAYERS };
}
function pushLobby() { for (const c of waiting()) send(c, lobbyInfo()); }

function tryCountdown() {
  if (room.phase !== 'lobby') return;
  const n = waiting().length;
  if (n >= MIN_PLAYERS && room.cd === null) {
    room.cd = COUNTDOWN;
    room.cdTimer = setInterval(() => {
      if (waiting().length < MIN_PLAYERS) { clearInterval(room.cdTimer); room.cdTimer = null; room.cd = null; pushLobby(); return; }
      room.cd--; if (room.cd <= 0) { clearInterval(room.cdTimer); room.cdTimer = null; room.cd = null; startMatch(); } else pushLobby();
    }, 1000);
    pushLobby();
  } else if (n < MIN_PLAYERS && room.cdTimer) {
    clearInterval(room.cdTimer); room.cdTimer = null; room.cd = null; pushLobby();
  }
}

function startPacket(c, elapsed) {
  return { t: 'start', id: c.id, seed: room.seed, elapsed, total: participants().length,
    players: participants().map(p => ({ id: p.id, name: p.name })), taken: [...room.taken], drops: [...room.drops.values()] };
}
function startMatch() {
  const list = waiting().slice(0, MAX_PLAYERS);
  if (list.length < MIN_PLAYERS) { pushLobby(); return; }
  room.phase = 'playing'; room.seed = crypto.randomInt(1, 2 ** 31 - 1); room.t0 = Date.now();
  room.taken.clear(); room.drops.clear(); room.nStart = list.length;
  for (const c of list) { c.inMatch = true; c.alive = true; c.hp = 100; c.air = 1; c.wp = 'pistol'; c.dirty = false; }
  for (const c of list) send(c, startPacket(c, 0));
  for (const c of waiting()) send(c, lobbyInfo());
  console.log(new Date().toISOString(), 'match start with', list.length, 'players');
}
function joinInProgress(c) {
  c.inMatch = true; c.alive = true; c.hp = 100; c.air = 1; c.wp = 'pistol';
  send(c, startPacket(c, (Date.now() - room.t0) / 1000));
  bcast({ t: 'pjoin', id: c.id, name: c.name }, c, true);
  room.nStart++;
}
function checkWin() {
  if (room.phase !== 'playing') return;
  const a = aliveP();
  if (a.length <= 1 && room.nStart >= MIN_PLAYERS) endMatch(a[0] || null);
}
function endMatch(winner) {
  room.phase = 'ending';
  bcast({ t: 'end', winner: winner ? winner.id : null }, null, true);
  console.log(new Date().toISOString(), 'match end, winner', winner && winner.name);
  clearTimeout(room.endTimer);
  room.endTimer = setTimeout(() => {
    for (const c of clients) { c.inMatch = false; c.alive = false; c.joined = false; }   // clients leave; they re-queue by pressing Join again
    room.phase = 'lobby'; room.taken.clear(); room.drops.clear(); room.nStart = 0;
  }, 4000);
}
function dropClient(c) {
  if (!clients.has(c)) return;
  clients.delete(c);
  if (c.inMatch && c.alive) {
    c.alive = false;
    bcast({ t: 'dead', id: c.id, by: null, dc: 1, left: aliveP().length }, null, true);
    checkWin();
  }
  if (room.phase === 'lobby') { tryCountdown(); pushLobby(); }
  try { c.sock.destroy(); } catch (e) { }
}

const num = (v, lo, hi) => { v = +v; return Number.isFinite(v) ? Math.max(lo, Math.min(hi, v)) : 0; };
function onMessage(c, text) {
  if (++c.msgs > 4000 && Date.now() - c.mt < 10000) return dropClient(c);   // flood guard (~400 msg/s)
  if (Date.now() - c.mt > 10000) { c.mt = Date.now(); c.msgs = 0; }
  let m; try { m = JSON.parse(text); } catch (e) { return; }
  if (!m || typeof m.t !== 'string') return;
  switch (m.t) {
    case 'join': {
      if (c.joined) return;
      c.name = cleanName(m.name); c.joined = true;
      send(c, { t: 'welcome', id: c.id, max: MAX_PLAYERS, need: MIN_PLAYERS });
      if (room.phase === 'playing' && (Date.now() - room.t0) / 1000 < JOIN_WINDOW && participants().length < MAX_PLAYERS) joinInProgress(c);
      else { send(c, lobbyInfo()); tryCountdown(); pushLobby(); }
      break;
    }
    case 'st': {
      if (!c.inMatch || !c.alive) return;
      c.x = num(m.x, -500, 500); c.y = num(m.y, -50, 400); c.z = num(m.z, -500, 500);
      c.yaw = num(m.yaw, -100, 100); c.pitch = num(m.pitch, -3, 3); c.hp = num(m.hp, 0, 300);
      c.air = num(m.air, 0, 3) | 0; c.spd = num(m.spd, 0, 40); if (typeof m.wp === 'string') c.wp = m.wp.slice(0, 16);
      c.dirty = true; break;
    }
    case 'shot': {
      if (!c.inMatch || !c.alive) return;
      bcast({ t: 'shot', id: c.id, ox: num(m.ox, -500, 500), oy: num(m.oy, -50, 400), oz: num(m.oz, -500, 500),
        tx: num(m.tx, -600, 600), ty: num(m.ty, -100, 400), tz: num(m.tz, -600, 600), wp: String(m.wp || '').slice(0, 16) }, c, true);
      break;
    }
    case 'hit': {
      if (!c.inMatch || !c.alive) return;
      const to = [...clients].find(x => x.id === m.to && x.inMatch && x.alive);
      if (!to || to === c) return;
      send(to, { t: 'hit', from: c.id, name: c.name, dmg: num(m.dmg, 0, 600), head: m.head ? 1 : 0, wp: String(m.wp || '').slice(0, 16) });
      break;
    }
    case 'dead': {
      if (!c.inMatch || !c.alive) return;
      c.alive = false;
      const by = typeof m.by === 'string' ? m.by : null, killer = by && [...clients].find(x => x.id === by);
      bcast({ t: 'dead', id: c.id, by: killer ? killer.id : null, wp: String(m.wp || '').slice(0, 16), left: aliveP().length }, null, true);
      checkWin();
      break;
    }
    case 'loot': {
      if (!c.inMatch || typeof m.id !== 'string' || m.id.length > 40) return;
      room.taken.add(m.id); room.drops.delete(m.id);
      bcast({ t: 'loot', id: m.id }, c, true); break;
    }
    case 'drop': {
      if (!c.inMatch || typeof m.id !== 'string' || m.id.length > 40 || !Array.isArray(m.items)) return;
      if (room.drops.size > 400) return;
      const d = { t: 'drop', id: m.id, x: num(m.x, -500, 500), z: num(m.z, -500, 500), type: String(m.type || '').slice(0, 16), items: m.items.slice(0, 8).map(i => String(i).slice(0, 16)) };
      room.drops.set(d.id, d); bcast(d, c, true); break;
    }
  }
}

// position broadcast
setInterval(() => {
  if (room.phase !== 'playing') return;
  const rows = [];
  for (const c of participants()) if (c.alive && c.dirty) {
    c.dirty = false;
    rows.push([c.id, +c.x.toFixed(2), +c.y.toFixed(2), +c.z.toFixed(2), +c.yaw.toFixed(3), +c.pitch.toFixed(2), c.wp, Math.round(c.hp), c.air, +c.spd.toFixed(1)]);
  }
  if (rows.length) bcast({ t: 'snap', p: rows }, null, true);
}, SNAP_MS);

// keep-alive
setInterval(() => {
  for (const c of clients) {
    if (!c.live) { dropClient(c); continue; }
    c.live = false; wsControl(c.sock, 9);
  }
}, 25000);
server.listen(PORT, () => console.log('Strike Zone server on http://localhost:' + PORT));
module.exports = { server, room, clients };
